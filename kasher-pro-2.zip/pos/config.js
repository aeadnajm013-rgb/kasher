// =====================================================
//  ڕێکخستنی ئەپ — تەنها ئەم فایلە دەستکاری بکە
// =====================================================

// ١) ئەمە لە Firebase Console > Project settings > Your apps > Web app کۆپی بکە
export const firebaseConfig = {
  apiKey: "AIzaSyDmObpmgtpWBDePZn16-oNGoLje7YRr--A",
  authDomain: "kasher-pro-dba2d.firebaseapp.com",
  projectId: "kasher-pro-dba2d",
  storageBucket: "kasher-pro-dba2d.firebasestorage.app",
  messagingSenderId: "878363161337",
  appId: "1:878363161337:web:8fcb0ee0df44f081072828",
  measurementId: "G-YLS17LTGVF"
};

// ٢) UIDی ئەکاونتەکەی خۆت (ئەدمین) — لە Firebase Console > Authentication > Users
export const ADMIN_UID = "LozsZU9UroQWz41XEGORGJyW3NE2";

// ٣) ژمارەی واتسئەپی خۆت (بێ + و بێ سفر لە پێش) — کڕیار بۆ کڕینی کۆد پەیوەندیت پێوە دەکات
export const SELLER_WHATSAPP = "9647821452786";

// ٤) ناردنی خۆکاری کۆد بۆ ئیمەیڵی کڕیار — لە emailjs.com (بێبەرامبەر، ٢٠٠ ئیمەیڵ لە مانگێکدا)
//    سەیری ڕێنمایی بکە بۆ ئەوەی ئەم سێ خانەیە پڕ بکەیتەوە
export const EMAILJS = {
  serviceId: "PASTE_SERVICE_ID",   // Email Services ← service_xxxx
  templateId: "PASTE_TEMPLATE_ID", // Email Templates ← template_xxxx
  publicKey: "PASTE_PUBLIC_KEY"    // Account ← Public Key
};

// ٥) ناوی ئەپەکە
export const APP_NAME = "کاشێر پرۆ";

// ٦) پلانەکان و نرخەکانیان (لە ڕێکخستن ← پلانەکان دەردەکەون)
// نرخ بەتاڵ بێت = «نرخ بپرسە» دەنووسرێت
export const PLANS = [
  { months: 6, price: "$75" },
  { months: 12, price: "$130" }
];
